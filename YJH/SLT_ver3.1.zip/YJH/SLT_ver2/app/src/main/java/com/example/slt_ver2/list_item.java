package com.example.slt_ver2;

public class list_item {

    private String sign;

    public list_item(String sign) {
        this.sign = sign;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
